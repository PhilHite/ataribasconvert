# ataribasconvert (Windows)

A Windows command line tool that converts a plain text Atari BASIC `.BAS` file by replacing all `0x0A` (Windows/Unix line feed) bytes with `0x9B` (Atari EOL bytes), making the file compatible with Atari BASIC on emulators such as Altirra.

## Requirements

Python must be installed on your Windows machine. It is available free from [https://www.python.org](https://www.python.org).

## Installation

1. Download both `ataribasconvert.bat` and `ataribasconvert.py`.
2. Place both files in the same folder. For system-wide access from any directory, copy both files to a folder that is on your system PATH, for example `C:\Windows\System32`.

## Usage

Open Command Prompt and run:

```
ataribasconvert INPUTFILE.BAS OUTPUTFILE.BAS
```

Example:

```
ataribasconvert PROGRAM.BAS PROGRAM_ATARI.BAS
```

The tool will report how many bytes were converted and where the output was written.

## Loading the converted file into an Atari 800 emulator

Once converted, load the file into an Atari 800 emulator using:

```
ENTER "H1:PROGRAM.BAS"
```

The emulator will respond with `READY`. You can then:

- `LIST` — display the program (use **Control+S** to pause scrolling)
- `LIST 100` — list from line 100 onwards
- `LIST 100,200` — list lines 100 through 200
- `RUN` — run the program
- `SAVE "H1:PROGRAM.BAS"` — save the program back to disk

## How it works

Atari BASIC uses `0x9B` as its end-of-line character, whereas files created or edited on Windows/Unix use `0x0A` (standard line feed). The `.bat` file passes your arguments to `ataribasconvert.py`, which performs a binary find-and-replace to make the file readable by Atari BASIC.

@echo off
python "%~dp0ataribasconvert.py" %*

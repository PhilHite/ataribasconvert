@echo off
:: ataribasconvert.bat
:: Wrapper to call ataribasconvert.py with Python
:: Place this file in the same folder as ataribasconvert.py

set SCRIPT_DIR=%~dp0
python "%SCRIPT_DIR%ataribasconvert.py" %*
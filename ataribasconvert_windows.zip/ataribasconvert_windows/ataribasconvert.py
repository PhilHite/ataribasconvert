#!/usr/bin/env python3
"""
ataribasconvert.py v1.01
Converts a plain text Atari BASIC .BAS file by replacing all 0x0A (Unix/Windows
line feed) bytes with 0x9B (Atari EOL bytes), making the file compatible with
Atari BASIC on emulators such as Altirra (Windows) and Atari800 (Linux).
If the source file does not end with a 0x0A byte, one is automatically appended
before conversion, ensuring the last line is always processed correctly.
"""

import sys
import os


def convert(input_path, output_path):
    if not os.path.isfile(input_path):
        print(f"Error: Input file '{input_path}' not found.")
        sys.exit(1)

    with open(input_path, "rb") as f:
        data = bytearray(f.read())

    # Ensure file ends with 0x0A before conversion
    if not data or data[-1] != 0x0A:
        data.append(0x0A)
        print("Note: Appended missing trailing newline (0x0A) to source data.")

    count = data.count(0x0A)
    converted = bytes(data).replace(b"\x0A", b"\x9B")

    with open(output_path, "wb") as f:
        f.write(converted)

    print(f"Converted {count} byte(s). Output written to: {output_path}")


def main():
    if len(sys.argv) != 3:
        print("Usage: ataribasconvert INPUTFILE.BAS OUTPUTFILE.BAS")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]
    convert(input_path, output_path)


if __name__ == "__main__":
    main()
